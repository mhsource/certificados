import * as React from 'react';
import Box from '@mui/material/Box'
import CssBaseline from '@mui/material/CssBaseline';
import TopBar from './topbar'
import SideBar from './sidebar';
import Container from './container';

import { InteractionType } from "@azure/msal-browser";
import { MsalAuthenticationTemplate, useMsal } from "@azure/msal-react";



const MainLayout = () => {
    return (
      //  <MsalAuthenticationTemplate interactionType={InteractionType.Redirect}>
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />
            <TopBar />
     
            <Container />
        </Box>
      //  </MsalAuthenticationTemplate>
    )
}

export default MainLayout;