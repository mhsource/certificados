import React, { useState, useEffect } from 'react';
import { Outlet } from "react-router-dom";
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Avatar } from "@mui/material";


//import { auth } from "../services/firebase";
import {  signInWithEmailAndPassword } from "firebase/auth";
import AlertDialog from './alert';

interface Service {
  accessKeyId: string;
  secretAccessKey: string;
  bucket: string;
  }
  
  const initialValues: Service = {
    accessKeyId: '',
    secretAccessKey: '',
    bucket:''
  };

const Login = () => {

  
const [values, setValues] = useState<Service>(initialValues);
const [open, setOpen] = React.useState(false);
const [data, setData] = React.useState('');

const handleClose = async () => {
   setOpen(false);
 };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = event.target;
    setValues({ ...values, [name]: value });
  };

  const handleSubmit = () => {

  //   signInWithEmailAndPassword(auth, values.email, values.password)
  // .then((userCredential) => {
  //   const user = userCredential.user;
     localStorage.setItem("token",JSON.stringify(values))
     window.location.reload();
  // })
  // .catch((error) => {
  //   const errorCode = error.code;
  //   const errorMessage = error.message;
  //   setData("Email ou senha incorreto!")
  //   setOpen(true);
  // });


   // handleClose();
  };

    return (
        <Box component="main" sx={{ flexGrow: 1, p: 3,paddingTop:'100px',display:'flex',flexDirection:'column' }}>


<AlertDialog
          open={open}
          data={data}
          onClose={handleClose}
        />

<TextField
              required
              fullWidth
              margin="normal"
              label="Access Key"
              name="accessKeyId"
              value={values.accessKeyId}
              onChange={handleChange}
            />

<TextField
              required
              fullWidth
              margin="normal"
              label="Secret Key"
              name="secretAccessKey"
              value={values.secretAccessKey}
              onChange={handleChange}
            />


<TextField
              required
              fullWidth
              margin="normal"
              label="Bucket de Logs"
              name="bucket"
              value={values.bucket}
              onChange={handleChange}
            />

    <Button onClick={handleSubmit} variant="contained" color="primary">Entrar</Button>


        </Box>
    )
}

export default Login;