
import { S3Client, ListObjectsV2Command,GetObjectCommand } from "@aws-sdk/client-s3";

const listBuckets = async () => {
  try {
    const token = JSON.parse(localStorage.getItem('token')!)

  const s3Client = new S3Client({ region: "us-east-1",
    credentials: {
      accessKeyId: token.accessKeyId,
      secretAccessKey: token.secretAccessKey
    }});
    const data = await s3Client.send(new ListObjectsV2Command({ Bucket: token.bucket,Delimiter:'/' }));
    return data.CommonPrefixes;
  } catch (error) {
    console.error("Error listing buckets:", error);
    throw error;
  }
};

const listLogsForAplication = async (prefix:string) => {
  try {
    const token = JSON.parse(localStorage.getItem('token')!)

    const s3Client = new S3Client({ region: "us-east-1",
      credentials: {
        accessKeyId: token.accessKeyId,
        secretAccessKey: token.secretAccessKey
      }});
    const data = await s3Client.send(new ListObjectsV2Command({ Bucket: token.bucket,Prefix:prefix }));
    const responseJson = JSON.stringify(data, null, 2);
    return JSON.parse(responseJson);
  } catch (error) {
    console.error("Error listing buckets:", error);
    throw error;
  }
};

const getLogs = async (key:string) => {
  try {
    const token = JSON.parse(localStorage.getItem('token')!)

    const s3Client = new S3Client({ region: "us-east-1",
      credentials: {
        accessKeyId: token.accessKeyId,
        secretAccessKey: token.secretAccessKey
      }});
    const command = new GetObjectCommand({
      Bucket: token.bucket,
      Key: key,
    });

    const response = await s3Client.send(command);

    // Lê o conteúdo do corpo do objeto como uma string
    const content = await streamToString(response.Body);

    return content ;
  } catch (error) {
    console.error("Erro ao obter o objeto:", error);
    throw error;
  }
};

const streamToString = async (stream:any) => {
  const reader = stream.getReader();
  let result = '';
  let done = false;

  while (!done) {
    const { value, done: isDone } = await reader.read();
    if (value) {
      result += new TextDecoder("utf-8").decode(value);
    }
    done = isDone;
  }
  return result;
};

export { listBuckets,listLogsForAplication,getLogs };

