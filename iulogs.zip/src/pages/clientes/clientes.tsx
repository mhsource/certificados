import React, { useEffect } from 'react';
import {  Chip } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { listBuckets } from '../../services/apis';
import { useNavigate } from 'react-router-dom';
import { CommonPrefix } from '@aws-sdk/client-s3';



export default function Clientes() {

  const [rows, setRows] = React.useState<CommonPrefix[]>([]);

  const navigate = useNavigate();

  const handleClickOpene = async(demanda:any) => {

    navigate('/logs/'+demanda);
  

  };


  const getpastas = async () => {

    const buckets = await listBuckets()

    console.log(buckets)

    setRows(buckets!)
  };


  useEffect(() => {

    getpastas()

  }, []);



  return (
    <>

    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="services table">
        <TableHead>
          <TableRow>
            <TableCell>Aplicações</TableCell>
            <TableCell></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((service) => (
            <TableRow key={service.Prefix}>
              <TableCell>{service.Prefix}</TableCell>
              <TableCell>
              <Chip label="Visualizar logs" onClick={() => handleClickOpene(service.Prefix)} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>

 </>
  );
}
