import * as React from 'react';
import { useState } from "react";
import { Dialog, DialogContent, Button, styled, alpha, AppBar, Box } from "@mui/material";

import Toolbar from '@mui/material/Toolbar';
import InputBase from '@mui/material/InputBase';
import SearchIcon from '@mui/icons-material/Search';


export interface SimpleDialogProps {
  open: boolean;
  selectedValue:any;
  onClose: () => void;
}


export default function EditarCliente(props: SimpleDialogProps) {
  const { onClose, selectedValue,open } = props;
  const [formData, setFormData] = useState(selectedValue);
  const [searchTerm, setSearchTerm] = useState('');

  const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: '100%',
  }));
  
  const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }));

  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    width: '100%',
    '& .MuiInputBase-input': {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      [theme.breakpoints.up('sm')]: {
        width: '12ch',
        '&:focus': {
          width: '20ch',
        },
      },
    },
  }));


    // Função para lidar com mudanças no campo de entrada
    const handleSearchChange = (e:any) => {
      setSearchTerm(e.target.value);
    };
  
    // Função para destacar as ocorrências do texto de pesquisa
    const highlightText = (text:any, term:any) => {
      if (!term.trim()) return text;
      const regex = new RegExp(`(${term})`, 'gi');
      return text.replace(regex, '<mark>$1</mark>');
    };
  
    // Gerar o texto com as ocorrências destacadas
    const highlightedText = highlightText(formData, searchTerm);
  
  return (
    <Dialog open={open} onClose={onClose}  fullScreen>

<AppBar position="static">
        <Toolbar>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Pesquisar..."
              inputProps={{ 'aria-label': 'search' }}
              value={searchTerm}
              onChange={handleSearchChange}
            />
          </Search>
          <Button onClick={onClose} style={{color:"white"}}>Sair</Button>
        </Toolbar>
        
      </AppBar>

      <DialogContent>
      <pre dangerouslySetInnerHTML={{ __html: highlightedText }}></pre>
      </DialogContent>
    </Dialog>
  );
};
