import React, {  useEffect } from 'react';
import {  Chip } from '@mui/material';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { listLogsForAplication,getLogs } from '../../services/apis';
import { useNavigate, useParams } from 'react-router-dom';
import EditarCliente from './editarCliente';



export default function ClientesLogs() {
  const [opene, setOpene] = React.useState(false);
  const [rows, setRows] = React.useState<any[]>([]);

  const { pasta } = useParams();

  const navigate = useNavigate();


  const [data, setData] = React.useState<String>();

  const handleClickVoltar = async() => {

 
    
    navigate('/');
  

  };

  const handleClickOpene = async(demanda:any) => {
    const logs = await getLogs(demanda)
    console.log(logs)
    setOpene(true);
    setData(logs)
  };

  const handleClosee = async () => {
     setOpene(false);
   };

  const getpastas = async () => {
    const pastas = await listLogsForAplication(pasta!)
    const files = pastas.Contents
  .filter((content: { Key: string; }) => !content.Key.endsWith('/'))
  .map((content: { Key: any; }) => content.Key);
    setRows(files)
  };


  useEffect(() => {

    getpastas()

  }, []);

  return (
    <>

{ data && <EditarCliente
        
        selectedValue={data}
          open={opene}
          onClose={handleClosee}

        />

   }

    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="services table">
        <TableHead>
          <TableRow>
            <TableCell> <Chip label="Voltar" onClick={() => handleClickVoltar()} /></TableCell>
            <TableCell></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((service) => (
            <TableRow key={service}>
              <TableCell>{service}</TableCell>
              <TableCell>
              <Chip label="Visualizar log" onClick={() => handleClickOpene(service)} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>

 </>
  );
}
