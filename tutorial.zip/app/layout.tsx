import * as React from 'react';
import { AppProvider } from '@toolpad/core/nextjs';
import DashboardIcon from '@mui/icons-material/Dashboard';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { AppRouterCacheProvider } from '@mui/material-nextjs/v15-appRouter';
import type { Navigation } from '@toolpad/core/AppProvider';
import LinearProgress from '@mui/material/LinearProgress';
import theme from '../theme';

const NAVIGATION: Navigation = [
  {
    segment: 'lotes',
    title: 'Manutenção de Lotes',
    icon: <DashboardIcon />,
  },
  {
    segment: 'flags',
    title: 'Flags',
    icon: <DashboardIcon />,
  },
];

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" data-toolpad-color-scheme="light">
      <body>
        <AppRouterCacheProvider options={{ enableCssLayer: true }}>
          <React.Suspense fallback={<LinearProgress />}>
            <AppProvider theme={theme} navigation={NAVIGATION}   branding={{
    logo: <img src="https://mui.com/static/logo.png" alt="MUI logo" />,
    title: 'Import',
    homeUrl: '/',

  }}>
              {children}
            </AppProvider>
          </React.Suspense>
        </AppRouterCacheProvider>
      </body>
    </html>
  );
}
