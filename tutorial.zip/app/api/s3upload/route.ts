// app/api/s3upload/route.ts
import { NextResponse } from 'next/server';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { SSMClient, GetParametersByPathCommand } from '@aws-sdk/client-ssm';
import sqlite3 from 'sqlite3';



// Ler variáveis de ambiente do Next.js (arquivo .env.local, .env, etc.)
const REGION = process.env.AWS_REGION || 'us-east-2';
const BUCKET = process.env.AWS_BUCKET_NAME || 'teste-ev';
const ACCESS_KEY_ID = 'AKIARSU7KVF5YOTKJMGJ';
const SECRET_ACCESS_KEY = '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';


// Cria um cliente S3 com as credenciais
const s3Client = new S3Client({
  region: REGION,
  credentials: {
    accessKeyId: ACCESS_KEY_ID,
    secretAccessKey: SECRET_ACCESS_KEY,
  },
});

const ssmClient = new SSMClient({   region: REGION,
    credentials: {
      accessKeyId: ACCESS_KEY_ID,
      secretAccessKey: SECRET_ACCESS_KEY,
    }, });


export async function PUT(request: Request) {

    const command = new GetParametersByPathCommand({
        Path: '/feature-flags/',
        Recursive: true, // Inclui todos os subparâmetros
        WithDecryption: true, // Necessário se usar SecureString
    });

    const response = await ssmClient.send(command);

    // Converte a resposta em um objeto chave-valor
    const featureFlags = response.Parameters?.reduce((flags:any, param:any) => {
        const flagName = param.Name.split('/').pop(); // Extrai o nome da flag
        flags[flagName] = param.Value === 'true'; 
        return flags;
    }, {});

    console.log(featureFlags)


return NextResponse.json({
    success: true,
    message: featureFlags,
  });

}



export async function POST(request: Request) {
  try {
    // Lê o JSON que o front-end enviou
    const body = await request.json();

    // Converte o objeto em string
    const jsonString = JSON.stringify(body, null, 2);

    // Define a "chave" (nome) do arquivo a ser salvo no S3
    const objectKey = `dados/${body.id_envio_lote}.json`;

    // Envia para o S3
    const putCommand = new PutObjectCommand({
      Bucket: BUCKET,
      Key: objectKey,
      Body: jsonString,
      ContentType: 'application/json',
    });

    await s3Client.send(putCommand);

    return NextResponse.json({
      success: true,
      message: `Upload concluído no bucket "${BUCKET}" com a key "${objectKey}".`,
    });
  } catch (error) {
    console.error('Erro ao enviar ao S3:', error);
    return NextResponse.json(
      { success: false, error: 'Falha ao subir arquivo no S3.' },
      { status: 500 }
    );
  }
}
