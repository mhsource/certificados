import { NextResponse } from 'next/server';
import {
  SSMClient,
  GetParametersByPathCommand,
  PutParameterCommand,
  DeleteParameterCommand,
} from '@aws-sdk/client-ssm';

const REGION = process.env.AWS_REGION || 'us-east-2';
const client = new SSMClient({
  region: REGION,
  credentials: {
    accessKeyId: 'AKIARSU7KVF5YOTKJMGJ',
    secretAccessKey: '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',
  },
});

// Obtém todos os parâmetros no caminho "/"
export async function GET() {
  try {
    const command = new GetParametersByPathCommand({
      Path: '/',
      Recursive: true,
      WithDecryption: true,
    });
    const response = await client.send(command);

    return NextResponse.json(response.Parameters || []);
  } catch (error) {
    console.error('Erro ao listar parâmetros:', error);
    return NextResponse.json({ error: 'Erro ao listar parâmetros' }, { status: 500 });
  }
}

// Cria ou atualiza um parâmetro
export async function POST(request: Request) {
  try {
    const { Name, Value, Type } = await request.json();

    const command = new PutParameterCommand({
      Name,
      Value,
      Type,
      Overwrite: true,
    });
    await client.send(command);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Erro ao salvar parâmetro:', error);
    return NextResponse.json({ error: 'Erro ao salvar parâmetro' }, { status: 500 });
  }
}

// Exclui um parâmetro
export async function DELETE(request: Request) {
  try {
    const { Name } = await request.json();

    const command = new DeleteParameterCommand({
      Name,
    });
    await client.send(command);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Erro ao excluir parâmetro:', error);
    return NextResponse.json({ error: 'Erro ao excluir parâmetro' }, { status: 500 });
  }
}
