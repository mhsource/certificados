import { S3Client, ListObjectsV2Command } from '@aws-sdk/client-s3';
import React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Link from 'next/link';

// Variáveis de ambiente (no .env, por exemplo)
  // Ler variáveis de ambiente do Next.js (arquivo .env.local, .env, etc.)
  const REGION = process.env.AWS_REGION || 'us-east-2';
  const BUCKET = process.env.AWS_BUCKET_NAME || 'teste-ev';
  const ACCESS_KEY_ID = 'AKIARSU7KVF5YOTKJMGJ';
  const SECRET_ACCESS_KEY = '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';
  
async function listarDiretoriosS3(): Promise<string[]> {


// Cria um cliente S3 com as credenciais
const s3 = new S3Client({
  region: REGION,
  credentials: {
    accessKeyId: ACCESS_KEY_ID,
    secretAccessKey: SECRET_ACCESS_KEY,
  },
});

  // Delimiter: '/' faz o S3 agrupar tudo que vem antes de cada "/"
  // em CommonPrefixes, simulando "pastas".
  const command = new ListObjectsV2Command({
    Bucket: BUCKET,
    Delimiter: '/',
  });

  try {
    const response = await s3.send(command);

    // Se existirem "CommonPrefixes", cada prefixo representa um diretório.
    // Ex: "0019897-b9aa-4335-964d-13ae3fd92b6d/"
    const prefixes = response.CommonPrefixes || [];

    // Remove a barra final para ficar só "0019897-b9aa-4335-964d-13ae3fd92b6d"
    return prefixes.map((cp) => {
      const prefix = cp.Prefix || '';
      return prefix.endsWith('/') ? prefix.slice(0, -1) : prefix;
    });
  } catch (error) {
    console.error('Erro ao listar diretórios do S3:', error);
    return [];
  }
}

// Componente server-side que lista os lotes (diretórios)
export default async function LotesPage() {
  // Carrega os "diretórios" no momento da renderização
  const lotes = await listarDiretoriosS3();

  return (
    <TableContainer component={Paper} sx={{ p: 2 }}>

      {lotes.length === 0 ? (
        <Typography>Nenhum lote encontrado.</Typography>
      ) : (
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Lotes</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {lotes.map((lote) => (
              <TableRow key={lote}>
                <TableCell>
                  {/*
                    Link para /lote/[codigoLote].
                    Ex: se "lote" = "0019897-b9aa-4335-964d-13ae3fd92b6d",
                    iremos para "/lote/0019897-b9aa-4335-964d-13ae3fd92b6d".
                  */}
                  <Link href={`/lotes/${lote}`}>
                    {lote}
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </TableContainer>
  );
}
