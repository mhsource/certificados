import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { notFound } from 'next/navigation';
import { Readable } from 'stream';
import React from 'react';
import LoteDetalhe from './LoteDetalhe';

const REGION = process.env.AWS_REGION || 'us-east-2';
const BUCKET = process.env.AWS_BUCKET_NAME || 'teste-ev';
const ACCESS_KEY_ID = 'AKIARSU7KVF5YOTKJMGJ';
const SECRET_ACCESS_KEY = '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';

const s3Client = new S3Client({
  region: REGION,
  credentials: {
    accessKeyId: ACCESS_KEY_ID,
    secretAccessKey: SECRET_ACCESS_KEY,
  },
});

/**
 * Gera uma URL pré-assinada para um arquivo no S3.
 */
async function gerarUrlPreAssinada(Key: string): Promise<string> {
  try {
    const command = new GetObjectCommand({ Bucket: BUCKET, Key });
    return await getSignedUrl(s3Client, command, { expiresIn: 3600 }); // URL válida por 1 hora
  } catch (error) {
    console.error('Erro ao gerar URL pré-assinada:', error);
    return '#'; // URL inválida em caso de erro
  }
}

/**
 * Lê o arquivo <lote>/<lote>.txt no S3, gera URLs pré-assinadas e retorna como JSON.
 */
async function lerArquivoTxt(lote: string): Promise<any | null> {
  const Key = `${lote}/${lote}.txt`;

  try {
    const command = new GetObjectCommand({
      Bucket: BUCKET,
      Key,
    });
    const response = await s3Client.send(command);

    if (!response.Body) return null;

    const stream = response.Body as Readable;
    let data = '';
    for await (const chunk of stream) {
      data += chunk.toString();
    }

    // Parse o JSON do .txt
    const parsedData = JSON.parse(data);

    // Gera URLs pré-assinadas para cada arquivo listado no JSON
    for (const conteudo of parsedData.conteudos) {
      if (conteudo.arquivos) {
        for (const arquivo of conteudo.arquivos) {
          arquivo.url_pre_assinada = await gerarUrlPreAssinada(`${lote}/${arquivo.nome_arquivo}`);
        }
      }
    }

    return parsedData;
  } catch (error) {
    console.error('Erro ao ler arquivo do S3:', error);
    return null;
  }
}

/**
 * Server Component:
 *  - Recebe `params.codigoLote`
 *  - Lê do S3 o arquivo "<codigoLote>/<codigoLote>.txt"
 *  - Gera URLs pré-assinadas para os arquivos listados
 *  - Caso sucesso, passa para o Client Component <LoteDetalhe />
 */
export default async function LoteDetailPage({
  params,
}: {
  params: { codigoLote: string };
}) {
  const { codigoLote } = params;

  const dados = await lerArquivoTxt(codigoLote);
  if (!dados) {
    notFound();
  }

  return (
    <LoteDetalhe
      codigoLote={codigoLote}
      dadosInit={dados}
    />
  );
}
