'use client';

import React, { useState } from 'react';
import {
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Collapse,
  Box,
  TextField,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
} from '@mui/material';
import { Delete as DeleteIcon } from '@mui/icons-material';

/**
 * Estrutura do JSON lido do S3, ajustando conforme seu caso real
 */
interface Metadado {
  codigo_metadado: string;
  valor_metadado: string;
}

interface Arquivo {
  id_arquivo: string;
  nome_arquivo: string;
  descricao_arquivo: string;
  tamanho_arquivo: string;
  sha256_arquivo: string;
  url_pre_assinada: string;
}

interface Conteudo {
  id_conteudo_custodiante: string;
  data_criacao_conteudo: string | null;
  data_validade_conteudo: string | null;
  data_expurgo_meses: string | null;
  categoria_conteudo: string;
  indicador_migracao_arquivo: string;
  arquivos?: Arquivo[];
  metadados: Metadado[];
  error?: string;
  editado?: boolean;
  id_tipo_conteudo?: string;
  id_processo?: string;
}

interface LoteData {
  id_envio_lote: string;
  conteudos: Conteudo[];
}

interface LoteDetalheProps {
  codigoLote: string;
  dadosInit: LoteData; // JSON lido do S3
}

/**
 * Componente CLIENT
 */
export default function LoteDetalhe({ codigoLote, dadosInit }: LoteDetalheProps) {
  const [dados, setDados] = useState<LoteData>(dadosInit);

  // Estado para controlar o modal do PDF
  const [openPdfModal, setOpenPdfModal] = useState(false);
  const [currentPdfUrl, setCurrentPdfUrl] = useState<string | null>(null);

  // Abrir o modal com a URL do PDF
  const handleOpenPdf = (url: string) => {
    setCurrentPdfUrl(url);
    setOpenPdfModal(true);
  };

  // Fechar o modal
  const handleClosePdf = () => {
    setCurrentPdfUrl(null);
    setOpenPdfModal(false);
  };

  /**
   * Lógica para enviar os dados para importação:
   * - Remove o campo `error` de cada conteúdo antes de enviar.
   */
  const handleEncaminhar = async () => {
    const dadosSemErro = {
      ...dados,
      conteudos: dados.conteudos.map(({ error, ...rest }) => rest),
    };

    try {
      const response = await fetch('/api/s3upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dadosSemErro),
      });

      const result = await response.json();
      if (result.success) {
        alert(`Upload feito com sucesso: ${result.message}`);
      } else {
        alert(`Falha no upload: ${result.error}`);
      }
    } catch (error) {
      console.error('Erro ao enviar para importação:', error);
      alert('Erro ao tentar enviar os dados.');
    }
  };

  const handleEncaminharV = async () => {

      const response = await fetch('/api/s3upload', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });

      const result = await response.json();

      console.log(result)

  };

  // Componente Row para cada conteúdo
  function Row({ item }: { item: Conteudo }) {
    const [open, setOpen] = useState(false);
    const [metadados, setMetadados] = useState<Metadado[]>(item.metadados);

    // Salvar => atualiza o estado global `dados` para incluir `editado: true`
    const handleSave = () => {
      setOpen(false);

      setDados((prev) => ({
        ...prev,
        conteudos: prev.conteudos.map((c) =>
          c.id_conteudo_custodiante === item.id_conteudo_custodiante
            ? { ...c, metadados, editado: true }
            : c
        ),
      }));
    };

    const handleChangeMetadado = (idx: number, campo: keyof Metadado, valor: string) => {
      setMetadados((prev) =>
        prev.map((m, i) => (i === idx ? { ...m, [campo]: valor } : m))
      );
    };

    const handleAddMetadado = () => {
      setMetadados((prev) => [...prev, { codigo_metadado: '', valor_metadado: '' }]);
    };

    const handleRemoveMetadado = (idx: number) => {
      setMetadados((prev) => prev.filter((_, i) => i !== idx));
    };

    return (
      <>
        {/* Linha principal */}
        <TableRow sx={{ backgroundColor: item.editado ? 'yellow' : 'inherit' }}>
          <TableCell>{item.id_conteudo_custodiante}</TableCell>
          <TableCell>{item.error || 'N/A'}</TableCell>
          <TableCell>{item.editado ? 'editado' : 'não editado'}</TableCell>
          <TableCell>
            <Button variant="outlined" onClick={() => setOpen(!open)}>
              Detalhes
            </Button>
          </TableCell>
        </TableRow>

        {/* Linha colapsável */}
        <TableRow>
          <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={4}>
            <Collapse in={open} timeout="auto" unmountOnExit>
              <Box margin={1}>

                <Table size="small">
                  <TableBody>


                    <TableRow>
                      <TableCell>Categoria</TableCell>
                      <TableCell>{item.categoria_conteudo || 'N/A'}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>Tipo Conteudo</TableCell>
                      <TableCell>{item.id_tipo_conteudo || 'N/A'}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>Data Criação</TableCell>
                      <TableCell>{item.data_criacao_conteudo || 'N/A'}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>Data Validade</TableCell>
                      <TableCell>{item.data_validade_conteudo || 'N/A'}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Data Expurgo</TableCell>
                      <TableCell>{item.data_expurgo_meses || 'N/A'}</TableCell>
                    </TableRow>
                    {item.arquivos && item.arquivos.length > 0 && (
                      <>
                        <TableRow>
                          <TableCell colSpan={2}>
                            <Typography variant="subtitle1" gutterBottom>
                              Arquivos
                            </Typography>
                          </TableCell>
                        </TableRow>
                        {item.arquivos.map((arq) => (
                          <React.Fragment key={arq.id_arquivo}>
                            <TableRow>
                              <TableCell>Nome Arquivo</TableCell>
                              <TableCell>
                                <Button
                                  variant="text"
                                  onClick={() => handleOpenPdf(arq.url_pre_assinada)}
                                >
                                  {arq.nome_arquivo}
                                </Button>
                              </TableCell>
                            </TableRow>
                          </React.Fragment>
                        ))}
                      </>
                    )}
                  </TableBody>
                </Table>

                {/* Metadados (Editáveis) */}
                <Box mt={3}>
                  <Typography variant="h6" gutterBottom>
                    Metadados (Editáveis)
                  </Typography>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Código Metadado</TableCell>
                        <TableCell>Valor</TableCell>
                        <TableCell>Ações</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {metadados.map((m, idx) => (
                        <TableRow key={idx}>
                          <TableCell>
                            <TextField
                              variant="outlined"
                              size="small"
                              value={m.codigo_metadado}
                              onChange={(e) =>
                                handleChangeMetadado(idx, 'codigo_metadado', e.target.value)
                              }
                            />
                          </TableCell>
                          <TableCell>
                            <TextField
                              variant="outlined"
                              size="small"
                              value={m.valor_metadado}
                              onChange={(e) =>
                                handleChangeMetadado(idx, 'valor_metadado', e.target.value)
                              }
                            />
                          </TableCell>
                          <TableCell>
                            <IconButton size="small" onClick={() => handleRemoveMetadado(idx)}>
                              <DeleteIcon />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))}
                      <TableRow>
                        <TableCell colSpan={3}>
                          <Button variant="outlined" onClick={handleAddMetadado}>
                            Adicionar Metadado
                          </Button>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                  <Box mt={2}>
                    <Button variant="contained" color="primary" onClick={handleSave}>
                      Salvar
                    </Button>
                  </Box>
                </Box>
              </Box>
            </Collapse>
          </TableCell>
        </TableRow>
      </>
    );
  }

  // Renderização principal
  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h5" gutterBottom>
        Detalhes do Lote: {codigoLote}
      </Typography>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID do conteúdo</TableCell>
              <TableCell>Erro Encontrado</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Ações</TableCell>
              <TableCell>
                <Button variant="contained" onClick={handleEncaminhar}>
                  Encaminhar para Importação
                </Button>

                <Button variant="contained" onClick={handleEncaminharV}>
                  Encaminha
                </Button>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {dados.conteudos.map((item) => (
              <Row key={item.id_conteudo_custodiante} item={item} />
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Modal para exibir o PDF */}
      <Dialog open={openPdfModal} onClose={handleClosePdf} fullWidth maxWidth="lg">
        <DialogTitle>Visualizar Arquivo PDF</DialogTitle>
        <DialogContent>
          {currentPdfUrl && (
            <iframe
              src={currentPdfUrl}
              width="100%"
              height="500px"
              style={{ border: 'none' }}
              title="PDF Viewer"
            />
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
}
