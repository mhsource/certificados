'use client';

import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
} from '@mui/material';
import { Delete as DeleteIcon, Edit as EditIcon, Add as AddIcon } from '@mui/icons-material';

/**
 * Interface para os parâmetros do Parameter Store
 */
interface Parameter {
  Name: string;
  Value: string;
  Type: string;
}

export default function FlagsPage() {
  const [parameters, setParameters] = useState<Parameter[]>([]);
  const [loading, setLoading] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingParameter, setEditingParameter] = useState<Parameter | null>(null);

  const [newName, setNewName] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newType, setNewType] = useState<'String' | 'SecureString' | 'StringList'>('String');

  /**
   * Carrega os parâmetros da API
   */
  const loadParameters = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/flags');
      const data = await response.json();
      setParameters(data);
    } catch (error) {
      console.error('Erro ao carregar parâmetros:', error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Salva ou edita um parâmetro via API
   */
  const saveParameter = async () => {
    if (!newName || !newValue) {
      alert('Preencha todos os campos!');
      return;
    }

    try {
      const response = await fetch('/api/flags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          Name: newName,
          Value: newValue,
          Type: newType,
        }),
      });

      const result = await response.json();
      if (result.success) {
        alert('Parâmetro salvo com sucesso!');
        setOpenDialog(false);
        loadParameters();
      } else {
        alert('Erro ao salvar parâmetro.');
      }
    } catch (error) {
      console.error('Erro ao salvar parâmetro:', error);
    }
  };

  /**
   * Exclui um parâmetro via API
   */
  const deleteParameter = async (name: string) => {
    if (!confirm(`Deseja realmente excluir o parâmetro ${name}?`)) return;

    try {
      const response = await fetch('/api/flags', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ Name: name }),
      });

      const result = await response.json();
      if (result.success) {
        alert('Parâmetro excluído com sucesso!');
        loadParameters();
      } else {
        alert('Erro ao excluir parâmetro.');
      }
    } catch (error) {
      console.error('Erro ao excluir parâmetro:', error);
    }
  };

  /**
   * Abre o diálogo para adicionar/editar um parâmetro
   */
  const handleOpenDialog = (parameter?: Parameter) => {
    if (parameter) {
      setEditingParameter(parameter);
      setNewName(parameter.Name);
      setNewValue(parameter.Value);
      setNewType(parameter.Type as 'String' | 'SecureString' | 'StringList');
    } else {
      setEditingParameter(null);
      setNewName('');
      setNewValue('');
      setNewType('String');
    }
    setOpenDialog(true);
  };

  /**
   * Fecha o diálogo de edição
   */
  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  /**
   * Efeito para carregar os parâmetros ao montar o componente
   */
  useEffect(() => {
    loadParameters();
  }, []);

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h5" gutterBottom>
        Dashboard - Flags (Parameter Store CRUD)
      </Typography>

      <Button
        variant="contained"
        startIcon={<AddIcon />}
        onClick={() => handleOpenDialog()}
        sx={{ mb: 2 }}
      >
        Adicionar Parâmetro
      </Button>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Nome</TableCell>
              <TableCell>Valor</TableCell>
              <TableCell>Tipo</TableCell>
              <TableCell align="right">Ações</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {parameters.map((param) => (
              <TableRow key={param.Name}>
                <TableCell>{param.Name}</TableCell>
                <TableCell>{param.Value}</TableCell>
                <TableCell>{param.Type}</TableCell>
                <TableCell align="right">
                  <IconButton
                    color="primary"
                    onClick={() => handleOpenDialog(param)}
                  >
                    <EditIcon />
                  </IconButton>
                  <IconButton
                    color="secondary"
                    onClick={() => deleteParameter(param.Name)}
                  >
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Diálogo para Adicionar/Editar Parâmetro */}
      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>{editingParameter ? 'Editar Parâmetro' : 'Adicionar Parâmetro'}</DialogTitle>
        <DialogContent>
          <TextField
            label="Nome"
            fullWidth
            margin="normal"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            disabled={!!editingParameter}
          />
          <TextField
            label="Valor"
            fullWidth
            margin="normal"
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
          />
          <TextField
            label="Tipo"
            fullWidth
            margin="normal"
            value={newType}
            onChange={(e) => setNewType(e.target.value as 'String' | 'SecureString' | 'StringList')}
            select
            SelectProps={{ native: true }}
          >
            <option value="String">String</option>
            <option value="SecureString">SecureString</option>
            <option value="StringList">StringList</option>
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancelar</Button>
          <Button variant="contained" onClick={saveParameter}>
            Salvar
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
