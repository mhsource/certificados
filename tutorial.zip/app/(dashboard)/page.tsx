import * as React from 'react';
import Typography from '@mui/material/Typography';
import Link from 'next/link';

export default function HomePage() {
  return (
    <Typography>
     Import
    </Typography>
  );
}
