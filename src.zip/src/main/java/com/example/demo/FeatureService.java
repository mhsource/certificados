package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ssm.SsmClient;
import software.amazon.awssdk.services.ssm.model.GetParameterRequest;
import software.amazon.awssdk.services.ssm.model.GetParameterResponse;

import java.util.concurrent.ConcurrentHashMap;

@Service
public class FeatureService {

    private final SsmClient ssmClient;

    // Cache com expiração
    private final ConcurrentHashMap<String, CacheEntry> cache = new ConcurrentHashMap<>();

    // Tempo de expiração em milissegundos (5 minutos)
    private static final long CACHE_EXPIRATION_MS = 5 * 60 * 1000;

    public FeatureService(
            @Value("${aws.accessKeyId}") String accessKeyId,
            @Value("${aws.secretAccessKey}") String secretAccessKey,
            @Value("${aws.region}") String region) {

        AwsBasicCredentials awsCredentials = AwsBasicCredentials.create(accessKeyId, secretAccessKey);

        this.ssmClient = SsmClient.builder()
                .region(Region.of(region))
                .credentialsProvider(StaticCredentialsProvider.create(awsCredentials))
                .build();
    }

    public String getFeatureFlag(String parameterName) {
        long currentTime = System.currentTimeMillis();

        // Verifica se o valor está no cache e ainda válido
        if (cache.containsKey(parameterName)) {
            CacheEntry cacheEntry = cache.get(parameterName);
            if ((currentTime - cacheEntry.timestamp) < CACHE_EXPIRATION_MS) {
                return cacheEntry.value; // Retorna o valor em cache
            }
        }

        // Busca o valor atualizado no Parameter Store
        try {
            GetParameterRequest request = GetParameterRequest.builder()
                    .name(parameterName)
                    .withDecryption(true)
                    .build();

            GetParameterResponse response = ssmClient.getParameter(request);
            String value = response.parameter().value();

            // Atualiza o cache com o novo valor e o timestamp atual
            cache.put(parameterName, new CacheEntry(value, currentTime));
            return value;

        } catch (Exception e) {
            System.err.println("Erro ao buscar parâmetro: " + e.getMessage());

            // Se ocorrer erro, tenta retornar o valor em cache (mesmo que expirado)
            return cache.containsKey(parameterName) ? cache.get(parameterName).value : null;
        }
    }

    // Classe auxiliar para armazenar valor e timestamp no cache
    private static class CacheEntry {
        String value;
        long timestamp;

        CacheEntry(String value, long timestamp) {
            this.value = value;
            this.timestamp = timestamp;
        }
    }
}

