package com.example.demo;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.*;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.IntPoint;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.*;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.*;

import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.*;
import software.amazon.awssdk.services.s3.model.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Service
public class LuceneIndexService {

    private final Analyzer analyzer;
    private final Directory indexDirectory;
    private final S3Client s3Client;

    public LuceneIndexService () throws IOException {
        // Inicializa o analisador e o diretório do índice
        this.analyzer = new StandardAnalyzer();
     //   this.indexDirectory = new RAMDirectory(); // Use FSDirectory para persistência
        this.indexDirectory = FSDirectory.open(Paths.get("./logs"));


        String access_key = "";
        String secret_key = "";

        // Cria as credenciais AWS
        AwsBasicCredentials awsCreds = AwsBasicCredentials.create(access_key, secret_key);

        // Inicializa o cliente S3 com as credenciais
        this.s3Client = S3Client.builder()
                .region(Region.US_EAST_1)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();
    }

    public void indexDocumentFromS3(String bucketName, String key,String loggroup) throws IOException {
        // Baixa o arquivo do S3 e indexa cada linha
        downloadAndIndexFileFromS3(bucketName, key,loggroup);
    }

    private void downloadAndIndexFileFromS3(String bucketName, String key,String loggroup) throws IOException {
        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .build();

        ResponseInputStream<GetObjectResponse> s3Object = s3Client.getObject(getObjectRequest);

        // Configura o IndexWriter uma vez para eficiência
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        try (IndexWriter writer = new IndexWriter(indexDirectory, config);
             BufferedReader reader = new BufferedReader(new InputStreamReader(s3Object, StandardCharsets.UTF_8))) {

            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) { // Opcional: Ignorar linhas vazias
                    indexLine(writer, key, lineNumber, line,loggroup);
                    lineNumber++;
                }
            }
        }
    }

    private void indexLine(IndexWriter writer, String fileId, int lineNumber, String content, String loggroup) throws IOException {
        Document doc = new Document();
        doc.add(new StringField("fileId", fileId, Field.Store.YES));
        doc.add(new IntPoint("lineNumber", lineNumber));
        doc.add(new StoredField("lineNumber", lineNumber)); // Armazena o número da linha para recuperação
        doc.add(new TextField("content", content, Field.Store.YES));
        doc.add(new StringField("loggroup", loggroup, Field.Store.YES));
        writer.addDocument(doc);
    }

    public List<Document> searchDocuments(String queryStr, String fileIdFilter, Integer lineNumberFilter,String loggroup) throws IOException, ParseException {
        List<Document> results = new ArrayList<>();
        try (DirectoryReader reader = DirectoryReader.open(indexDirectory)) {
            IndexSearcher searcher = new IndexSearcher(reader);

            BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();

            // Se a consulta não for vazia, adiciona a consulta de conteúdo
            if (queryStr != null && !queryStr.trim().isEmpty()) {
                QueryParser parser = new QueryParser("content", analyzer);
                Query contentQuery = parser.parse(queryStr);
                booleanQuery.add(contentQuery, BooleanClause.Occur.MUST);
            } else {
                // Se a consulta for vazia, adiciona uma consulta que corresponde a todos os documentos
                Query matchAllQuery = new MatchAllDocsQuery();
                booleanQuery.add(matchAllQuery, BooleanClause.Occur.MUST);
            }

            // Adiciona filtro por fileId
            if (fileIdFilter != null) {
                Query fileIdQuery = new TermQuery(new Term("fileId", fileIdFilter));
                booleanQuery.add(fileIdQuery, BooleanClause.Occur.FILTER);
            }

            // Adiciona filtro por fileId
            if (loggroup != null) {
                Query fileIdQuery = new TermQuery(new Term("loggroup", loggroup));
                booleanQuery.add(fileIdQuery, BooleanClause.Occur.FILTER);
            }

            // Adiciona filtro por lineNumber
            if (lineNumberFilter != null) {
                Query lineNumberQuery = IntPoint.newExactQuery("lineNumber", lineNumberFilter);
                booleanQuery.add(lineNumberQuery, BooleanClause.Occur.FILTER);
            }

            TopDocs topDocs = searcher.search(booleanQuery.build(), 1000); // Limite de 10 resultados

            for (ScoreDoc scoreDoc : topDocs.scoreDocs) {
                Document doc = searcher.doc(scoreDoc.doc);
                results.add(doc);
            }
        }
        return results;
    }
}