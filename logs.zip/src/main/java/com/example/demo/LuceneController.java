package com.example.demo;

import org.apache.lucene.document.Document;
import org.apache.lucene.queryparser.classic.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/lucene")
public class LuceneController {

    private final LuceneIndexService luceneService;

    @Autowired
    public LuceneController(LuceneIndexService luceneService) {
        this.luceneService = luceneService;
    }

    @PostMapping("/indexFromS3")
    public ResponseEntity<String> indexFromS3(@RequestBody Map<String, String> payload) {
        try {
            String bucketName = payload.get("bucketName");
            String key = payload.get("key");
            String loggroup = payload.get("loggroup");
            luceneService.indexDocumentFromS3(bucketName,key, loggroup);
            return ResponseEntity.ok("Documento indexado com sucesso a partir do S3.");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao indexar o documento do S3.");
        }
    }

    @GetMapping("/search")
    public ResponseEntity<List<Map<String, Object>>> search(
            @RequestParam(value = "query", required = false) String query,
            @RequestParam(required = false) String fileId,
            @RequestParam(required = false) String loggroup,
            @RequestParam(required = false) Integer lineNumber) {
        try {
            List<Document> docs = luceneService.searchDocuments(query, fileId, lineNumber,loggroup);
            List<Map<String, Object>> results = docs.stream().map(doc -> {
                Map<String, Object> map = new HashMap<>();
                map.put("fileId", doc.get("fileId"));
                map.put("loggroup", doc.get("loggroup"));
                map.put("lineNumber", doc.get("lineNumber"));
                map.put("content", doc.get("content"));
                return map;
            }).collect(Collectors.toList());
            return ResponseEntity.ok(results);
        } catch (IOException | ParseException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}