import os
from flask import Flask, Response, jsonify, request
import boto3
import time
from datetime import datetime, timedelta


from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Configurando o cliente S3
client = boto3.client(
    's3',
    region_name='us-east-1',
    aws_access_key_id="AKIAQE43KJQ2DPQ2TZKV",
    aws_secret_access_key="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"
)

clientlog = boto3.client(
    'logs',
    region_name='us-east-1',
    aws_access_key_id="AKIAQE43KJQ2DPQ2TZKV",
    aws_secret_access_key="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"
)

@app.route('/list-s3-pastas', methods=['GET'])
def list_s3_pastas():
    try:

        prefix = request.args.get('prefix', '')
       
        response = client.list_objects_v2(
            Bucket='logs-teste-exemplo',
            Delimiter='/'
            )
        contents = response.get('CommonPrefixes', [])
        return jsonify(contents), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route('/list-s3-objects', methods=['GET'])
def list_s3_objects():
    try:

        response = client.list_objects_v2(
            Bucket='logs-teste-exemplo',
            Prefix='aplicacao1/'
        )

        # Obtém a lista de objetos (arquivos e pastas)
        contents = response.get('Contents', [])

        # Filtra para incluir apenas os arquivos (exclui pastas que terminam com '/')
        files = [content['Key'] for content in contents if not content['Key'].endswith('/')]
        return jsonify(files), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route('/get-s3-object', methods=['GET'])
def get_s3_objects():
    try:

        response = client.get_object(
            Bucket='logs-teste-exemplo',
            Key='aplicacao1/logs_1724484207.txt'
        )

        content = response['Body'].read().decode('utf-8')
        
        return jsonify({"logs": content})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def get_last_hour_timestamps():
    # Obtém o timestamp atual
    end_time = datetime.now()
    
    # Subtrai 1 hora do tempo atual
    start_time = end_time - timedelta(hours=1)
    
    # Converte para Unix timestamp em milissegundos
    start_timestamp = int(start_time.timestamp() * 1000)
    end_timestamp = int(end_time.timestamp() * 1000)
    
    return start_timestamp, end_timestamp

@app.route('/filter-log-events', methods=['GET'])
def filter_log_events():
   
    log_group_name = "/aws/lambda/aplicacao1"
    log_stream_name = None
    filter_pattern = ""
    destination_bucket = "logs-teste-exemplo"
    destination_key = f'logs_{int(time.time())}.txt'

    if not log_group_name or not destination_bucket:
        return jsonify({"error": "Missing required parameters"}), 400

    try:
        # Obtém os timestamps da última hora
        start_time, end_time = get_last_hour_timestamps()

        # Filtra eventos de log
        response = clientlog.filter_log_events(
            logGroupName=log_group_name,
            startTime=start_time,
            endTime=end_time,
            filterPattern=filter_pattern
        )

        events = response.get('events', [])

        if not events:
            return jsonify({"message": "No events found"}), 200

        # Cria um arquivo temporário com os logs filtrados
        temp_file_path = f'./{destination_key}'
        with open(temp_file_path, 'w') as file:
            for event in events:
                file.write(f"{event['timestamp']}: {event['message']}\n")

        # Faz upload do arquivo para o bucket S3
        client.upload_file(temp_file_path, destination_bucket, f'aplicacao1/{destination_key}')

        # Remove o arquivo temporário
        os.remove(temp_file_path)

        return jsonify({"message": "Logs successfully uploaded", "s3_key": f'aplicacao1/{destination_key}'}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
