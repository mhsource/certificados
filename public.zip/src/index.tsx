 import * as React from 'react';
 import { createRoot } from 'react-dom/client';
 import CssBaseline from '@mui/material/CssBaseline';
 import { ThemeProvider } from '@mui/material/styles';
 import { BrowserRouter as Router } from "react-router-dom";
 import PortalRoutes from './routes/routes';
 import { createTheme } from '@mui/material/styles';
import { red } from '@mui/material/colors';
import { PublicClientApplication } from '@azure/msal-browser';
import { MsalProvider } from '@azure/msal-react';
import { msalConfig } from './authConfig';


const theme = createTheme({
  palette: {
    primary: { main: '#3e4349' },
    secondary: { main: '#19857b' },
    error: { main: red.A400 },
    background: { default: "#fafafa" }
  }
})




const msalInstance = new PublicClientApplication(msalConfig);

 const rootElement = document.getElementById('root');
 const root = createRoot(rootElement!);


/**
 * We recommend wrapping most or all of your components in the MsalProvider component. It's best to render the MsalProvider as close to the root as possible.
 */
 root.render(
  <React.StrictMode>
      <MsalProvider instance={msalInstance}>

       <ThemeProvider theme={theme}>
     <CssBaseline />
     <Router>
       <PortalRoutes />
     </Router>
   </ThemeProvider>,
      </MsalProvider>
  </React.StrictMode>
);