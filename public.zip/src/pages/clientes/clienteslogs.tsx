import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import { Card, CardContent, Chip } from '@mui/material';
import NovoCliente from './novoCliente';

import EditarCliente from './editarCliente';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { listS3Prefix,getLogS3Prefix } from '../../services/apis';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../../authConfig';
import { useParams } from 'react-router-dom';



export default function ClientesLogs() {
  const [open, setOpen] = React.useState(false);
  const [opene, setOpene] = React.useState(false);
  const [rows, setRows] = React.useState<any[]>([]);
  const [loadingData, setLoadingData] = React.useState(true);

  const { instance, accounts } = useMsal();

  const { pasta } = useParams();


  const [data, setData] = React.useState();

  const handleClickOpen = () => {
   // setOpen(true);


   instance
   .acquireTokenSilent({
       ...loginRequest,
       account: accounts[0],
   })
   .then((response) => {
    console.log(response.accessToken)
   });

  };

  const handleClickOpene = async(demanda:any) => {
    const logs = await getLogS3Prefix()
    console.log(logs)
    setOpene(true);
    setData(logs.logs)
  };

  const handleClose = async () => {
    setOpen(false);
  };

  const handleClosee = async () => {
     setOpene(false);
   };

  const [itens, setItens] = useState([]);

 

  const getpastas = async () => {
    const pastas = await listS3Prefix()
    console.log(pasta)
    setRows(pastas)
  };


  useEffect(() => {

    getpastas()

  }, []);


  function exportx(){
    ExportarExcel(rows,[
      "ID",
      "CPF/CNPJ",
      "Nome",
      "Data de Nascimento",
      "Telefone",
      "Email",
      "Endereço",
      "Bairro",
      "Cidade",
      "UF",
      "CEP",
      "Numero"
    ],'clientes')
  }

  return (
    <>

{ data && <EditarCliente
        
        selectedValue={data}
          open={opene}
          onClose={handleClosee}

        />

   }

    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="services table">
        <TableHead>
          <TableRow>
            <TableCell>Logs</TableCell>
            <TableCell></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((service) => (
            <TableRow key={service}>
              <TableCell>{service}</TableCell>
              <TableCell>
              <Chip label="Visualizar log" onClick={() => handleClickOpene(service)} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>

 </>
  );
}

function ExportarExcel(rows: any[], arg1: string[], arg2: string) {
  throw new Error('Function not implemented.');
}
