import * as React from 'react';
import { getCEP, putLinguagens } from '../../services/apis';

import { useState } from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField } from "@mui/material";

import { v4 as uuidv4 } from 'uuid';
import { ref, set, onChildAdded, onChildChanged, onChildRemoved, remove } from "firebase/database";

import {  database } from "../../services/firebase";

export interface SimpleDialogProps {
  open: boolean;
  selectedValue:any;
  onClose: () => void;
}


export default function EditarCliente(props: SimpleDialogProps) {
  const { onClose, selectedValue,open } = props;
  const [formData, setFormData] = useState(selectedValue);

  console.log(formData)

  const handleClose = () => {
    onClose()
  };





  return (
    <Dialog open={open} onClose={onClose}   maxWidth={"lg"}>
      <DialogContent>
      <pre> {formData} </pre>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Sair</Button>
      </DialogActions>
    </Dialog>
  );
};
