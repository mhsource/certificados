import * as React from 'react';
import { getCEP, putLinguagens } from '../../services/apis';

import { useState } from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField } from "@mui/material";

import { v4 as uuidv4 } from 'uuid';
import { ref, set, onChildAdded, onChildChanged, onChildRemoved } from "firebase/database";

import {  database } from "../../services/firebase";




export interface SimpleDialogProps {
  open: boolean;
  onClose: () => void;
}

interface Service {
  cpfcnpj: string;
  nome: string;
  nascimento: string;
  telefone: string;
  email: string;
  endereco: string;
  bairro: string;
  cidade: string;
  uf: string;
  cep: string;
  numero: string;
}

const initialValues: Service = {
  cpfcnpj: '',
  nome: '',
  nascimento: '',
  telefone: '',
  email: '',
  endereco: '',
  bairro: '',
  cidade: '',
  uf: '',
  cep: '',
  numero: ''
};

export default function NovoCliente(props: SimpleDialogProps) {
  const { onClose, open } = props;

   const [formData, setFormData] = useState<Service>(initialValues);

  const handleClose = () => {
    onClose()
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = () => {
    const db = database;
     set(ref(db, 'clientes/'+uuidv4()),formData );
    handleClose()
  };

  const handleChangeCep = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    if(value.length >7){
     const endereco = await getCEP(value)
     setFormData(prevState => ({
      ...prevState,
      "cep": value,
      "endereco": endereco.logradouro,
      "bairro": endereco.bairro,
      "cidade": endereco.localidade,
      "uf": endereco.uf
    }));

    }
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>Cadastro de Clientes</DialogTitle>
      <DialogContent>
        <TextField label="CPF ou CNPJ"  name="cpfcnpj"  margin="normal" value={formData.cpfcnpj} onChange={handleChange} fullWidth />
        <TextField label="Nome ou Razão social"  name="nome" margin="normal" value={formData.nome} onChange={handleChange} fullWidth />
        <TextField label="Data de nascimento" type="date"   InputLabelProps={{ shrink: true }} name="nascimento" margin="normal" value={formData.nascimento} onChange={handleChange} fullWidth />
        <TextField label="Telefone" name="telefone"  margin="normal" value={formData.telefone} onChange={handleChange} fullWidth />
        <TextField label="Email" name="email"  margin="normal" value={formData.email} onChange={handleChange} fullWidth />
        <TextField
            required
            fullWidth
            margin="normal"
            label="cep"
            name="cep"
            onChange={handleChangeCep}
          />
                    <TextField
            required
            fullWidth
            margin="normal"
            label="Endereço"
            name="endereco"
            value={formData.endereco}
            onChange={handleChange}
          />
                                                            <TextField
            required
            fullWidth
            margin="normal"
            label="Numero"
            name="numero"
            value={formData.numero}
            onChange={handleChange}
          />
                              <TextField
            required
            fullWidth
            margin="normal"
            label="Bairro"
            name="bairro"
            value={formData.bairro}
            onChange={handleChange}
          />
                                        <TextField
            required
            fullWidth
            margin="normal"
            label="Cidade"
            name="cidade"
            value={formData.cidade}
            onChange={handleChange}
          />
                                                  <TextField
            required
            fullWidth
            margin="normal"
            label="UF"
            name="uf"
            value={formData.uf}
            onChange={handleChange}
          />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancelar</Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">Cadastrar</Button>
      </DialogActions>
    </Dialog>
  );
};
