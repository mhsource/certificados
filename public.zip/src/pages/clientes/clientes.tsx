import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import { Card, CardContent, Chip } from '@mui/material';
import NovoCliente from './novoCliente';

import EditarCliente from './editarCliente';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { listS3Pastas } from '../../services/apis';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../../authConfig';
import { useNavigate } from 'react-router-dom';



export default function Clientes() {
  const [open, setOpen] = React.useState(false);
  const [opene, setOpene] = React.useState(false);
  const [rows, setRows] = React.useState<any[]>([]);
  const [loadingData, setLoadingData] = React.useState(true);

  const { instance, accounts } = useMsal();
  const navigate = useNavigate();



  const [data, setData] = React.useState();

  const handleClickOpen = () => {
   // setOpen(true);


   instance
   .acquireTokenSilent({
       ...loginRequest,
       account: accounts[0],
   })
   .then((response) => {
    console.log(response.accessToken)
   });

  };

  const handleClickOpene = async(demanda:any) => {

    navigate('/logs/'+demanda);
  

  };

  const handleClose = async () => {
    setOpen(false);
  };

  const handleClosee = async () => {
     setOpene(false);
   };

  const [itens, setItens] = useState([]);

 

  const getpastas = async () => {
    const pastas = await listS3Pastas()
    setRows(pastas)
  };


  useEffect(() => {

    getpastas()

  }, []);


  function exportx(){
    ExportarExcel(rows,[
      "ID",
      "CPF/CNPJ",
      "Nome",
      "Data de Nascimento",
      "Telefone",
      "Email",
      "Endereço",
      "Bairro",
      "Cidade",
      "UF",
      "CEP",
      "Numero"
    ],'clientes')
  }

  return (
    <>

    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="services table">
        <TableHead>
          <TableRow>
            <TableCell>Aplicações</TableCell>
            <TableCell></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((service) => (
            <TableRow key={service.Prefix}>
              <TableCell>{service.Prefix}</TableCell>
              <TableCell>
              <Chip label="Visualizar logs" onClick={() => handleClickOpene(service.Prefix)} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>

 </>
  );
}

function ExportarExcel(rows: any[], arg1: string[], arg2: string) {
  throw new Error('Function not implemented.');
}
